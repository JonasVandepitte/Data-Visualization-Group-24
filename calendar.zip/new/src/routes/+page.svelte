<!-- <h1>Welcome to SvelteKit</h1>
<p>Visit <a href="https://kit.svelte.dev">kit.svelte.dev</a> to read the documentation</p>
 -->
<script>
    // import Papa from 'papaparse'
    import Tooltip from './Tooltip.svelte';
    import Chart from 'chart.js/auto';
    // let df = Papa.parse('http://localhost:5173/dummy.csv', (e) => {console.log(e)})
    // console.log(df)
    export let data;
    // console.log(data);
    // let test = 30
    let offset = 100
    let orderMonth = 1

    data.orders.forEach(order => {
        order.week = Math.floor((order.day - 1) / 7);
        order.dow  = (order.day - 1) % 7;
        order.hpos = order.dow * offset;
        order.vpos = order.week * offset;
        if (order.lv == 'extreme low') {
            order.color = '#00838F';
        } else if (order.lv == 'low') {
            order.color = '#4DB6AC';
        } else if (order.lv == 'medium') {
            order.color = '#E0E0E0';
        } else if (order.lv == 'high') {
            order.color = '#FF8A65';
        } else if (order.lv == 'extreme high') {
            order.color = '#D84315';
        }
        
        // Blue color
        // if (order.lv == 'low') {
        //     order.color = '#87CEEB'
        // } else if (order.lv == 'med') {
        //     order.color = '#1E90FF'
        // } else {
        //     order.color = '#0000CD'
        // }
    });

    console.log(data.orders[0])
    // Update orders based on the selected month
    let orders
    $: orders = data.orders.filter(el => el.month == orderMonth);
    // let orders = data.orders.filter((el) => (el.OrderDate == orderMonth))
    let months = [...Array(12).keys()].map((x) => (x+1))
    
    //save months and weeks to show
    let daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    let monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September','October', 'November', 'December'];
    
    // mouse over function
    let tooltip = { content: '', visible: false, x: 0, y: 0 };

    let myChart;

    let chartPeriod = 'month';

    function showTooltip(event, order) {
        const data = {
            labels: [
                "ADVENTURING EQUIPMENT", "ANIMALS & TRANSPORTATION", "ARMS & ARMOUR",
                "JEWELRY", "MUSICAL INSTRUMENT", "POTIONS & SCROLLS", "SUMMONING DEVICE", "TOOLS & KITS"
            ],
            datasets: [{
                data: [
                    order["ADVENTURING EQUIPMENT"], order["ANIMALS & TRANSPORTATION"],
                    order["ARMS & ARMOUR"], order["JEWELRY"], order["MUSICAL INSTRUMENT"],
                    order["POTIONS & SCROLLS"], order["SUMMONING DEVICE"], order["TOOLS & KITS"]
                ],
                backgroundColor: [
                    '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#F77825', '#9966FF', '#C9CB3A', '#FF9F40'
                ]
            }]
        };

        console.log("Chart data:", data.datasets[0].data);  // 输出图表数据，验证是否每次都更新

        if (myChart) {
            myChart.destroy(); 
        }

        const ctx = document.getElementById('myChart').getContext('2d');
        myChart = new Chart(ctx, {
            type: 'pie', 
            data: data,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                }
            }
        });

        tooltip = {
            content: `Type of Purchases: Total ${order['sum_total']}`,
            visible: true,
            x: event.pageX + 100,
            y: event.pageY + 350
        };
    }

    function hideTooltip() {
        tooltip.visible = false;
    }

    let fy_offset = 20
    let fy_orderMonth = 1

    function getWeekNumber(date) {
    const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
    const pastDaysOfYear = (date - firstDayOfYear) / 86400000;
    
    return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
    }

    let colorConfig = {
        extreme_low: { color: '#00838F', label: 'Extreme Low' },
        low: { color: '#4DB6AC', label: 'Low' },
        medium: { color: '#E0E0E0', label: 'Medium' },
        high: { color: '#FF8A65', label: 'High' },
        extreme_high: { color: '#C62828', label: 'Extreme High' }
    };

    data.orders.forEach(order => {
        // order.week = Math.floor((order.index % 365) / 7);
        try {
        const orderDate = new Date(order.year, order.month - 1, order.day);
        order.fy_week = getWeekNumber(orderDate);
        order.fy_dayOfWeek = orderDate.getDay();
        order.fy_dow  = (order.day - 1) % 7;
        order.fy_vpos = order.fy_dayOfWeek * fy_offset;
        order.fy_hpos = order.fy_week * fy_offset;
        // console.log(order);
        if (order.lv == 'extreme low') {
            order.fy_color = '#00838F';
        } else if (order.lv == 'low') {
            order.fy_color = '#4DB6AC';
        } else if (order.lv == 'med') {
            order.fy_color = '#E0E0E0';
        } else if (order.lv == 'high') {
            order.fy_color = '#FF8A65';
        } else if (order.lv == 'extreme high') {
            order.fy_color = '#D84315';
        }
    } catch (error) {
        console.error('Error processing order:', order, error);
    }
    });

    console.log(data.orders[0])
    // Update orders based on the selected month
    
    //save months and weeks to show
    let years = ['2019', '2020', '2021', '2022', '2023'];
    // let monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September','October', 'November', 'December'];
    
    let legend = Object.entries(colorConfig).map(([key, value]) => ({
        color: value.color,
        label: value.label
    }))

    let monthSpacing = 10;
</script>

<style>
    svg {
        background-color:white
    }
    rect.outer {
        fill: white;
        opacity:50
    }
    text.day {
        font-size: 100%;
        font-family: 'Open Sans', sans-serif;
        fill: black
    }
    text.total {
        font-size: 150%;
        font-family: 'Open Sans', sans-serif;
        fill: black
    }
    /* text.label {
        font-size: 100%;
        font-family: "Lucida Console", "Courier New", monospace;
        fill: black;
    } */
    text.month-label {
        font-size: 300%;
        font-family: 'Open Sans', sans-serif;
        fill: black;
        text-anchor: middle;
    }
    .tooltip {
        position: fixed;
        padding: 8px;
        font-family: 'Open Sans', sans-serif;
        background-color: white;
        border: 1px solid #ccc;
        box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
        pointer-events: none;
        visibility: hidden;
        transform: translate(-50%, -100%);
        z-index: 100;
    }

    .tooltip.visible {
        visibility: visible;
    }
    
    text.label {
        font-size: 100%;
        font-family: 'Open Sans', sans-serif;
        fill: #757575;
    }
    text.month {
        font-size: 100%;
        font-family: 'Open Sans', sans-serif;
        fill: #757575;
        text-anchor: start;
    }
    text.title {
        font-size: 150%;
        font-family: 'Open Sans', sans-serif;
        fill: black;
    }
    .color-box {
        stroke: #000;
        stroke-width: 1;
    }
</style>

<select id="period" name="period" bind:value={chartPeriod}>
    <option value='month'>month</option>
    <option value='year'>year</option>
</select>

<input type="range" min="1" max="12" bind:value={orderMonth} />

<select id="month" name="month" bind:value={orderMonth}>
    {#each months as month}
        <option value={month}>{month}</option>
    {/each}
</select>
<br/><br/>


<!-- width=400 height=400 -->

<svg width="1400" height="1000" xmlns="http://www.w3.org/2000/svg">
    
    {#if chartPeriod === 'month'}
        <text class="month-label" x="30%" y="40">{monthNames[orderMonth-1]}</text>
        <!-- {#each daysOfWeek as day, index}
            <text class="label" x={offset * (index + 1) + 50} y="90">{day}</text>
        {/each} -->

        {#each orders as order}
            <text class="label" x="70" y={offset * (order.week + 1) + 50}>{order.week + 1}</text>
        {/each}

        {#each orders as order}
        <!-- svelte-ignore a11y-no-static-element-interactions -->
        <!-- svelte-ignore a11y-mouse-events-have-key-events -->
        <g 
            on:mouseover={event => showTooltip(event, order)}
            on:mouseout={hideTooltip}
            transform="translate({order.hpos + offset},{order.vpos + offset})"
        >
            <rect class="outer" width="105" height="105"></rect>
            <rect class="inner" x="5" y="5" width="98" height="98" fill={order.color}></rect>
            <text class="day" x="10" y="20">{order.day}</text>
            <text class="total" x="22" y="60">{order['sum_total']}</text>
        </g>
        {/each}
        {#each legend as item, index}
            <rect class="color-box" x="850" y={(index * 20 * 2) + 40} width="20" height="20" fill={item.color} rx="3" ry="3"></rect>
            <text class="label" x="880" y={(index * 20 * 2) + 55}>{item.label}</text>
        {/each}
    {/if}

    {#if chartPeriod === 'year'}
        {#each years as year, yearIndex}
            <text class="title" x=620 y={(yearIndex * fy_offset * 9) + fy_offset + 14}>{year}</text>
            {#each daysOfWeek as day, dayIndex}
                <text class="label" x="30" y={(yearIndex * 9 * fy_offset) + (dayIndex + 1) * fy_offset + fy_offset * 2 - 5}>{day}</text>
            {/each}
            {#each data.orders.filter(order => order.year === year) as order, orderIndex}
                {#if orderIndex === 0 || order.month !== data.orders[orderIndex - 1].month}
                    <text class="month" x={(order.fy_hpos + fy_offset + (order.month-1) * monthSpacing + 25)} y={((yearIndex + 1) * fy_offset * 9 - 10) + fy_offset}>
                        {monthNames[order.month - 1]}
                    </text>
                {/if}
                <g transform="translate({(order.fy_hpos + fy_offset*2 + (order.month-1) * monthSpacing)}, {yearIndex * (fy_offset * 9) + order.fy_vpos + fy_offset * 2})">
                    <rect class="inner" x="2" y="0" width="17" height="17" fill={order.color} rx="3" ry="3"
                    ></rect>
                </g>
            {/each}
        {/each}

        {#each legend as item, index}
            <rect class="color-box" x="1260" y={(index * fy_offset * 2) + 40} width="20" height="20" fill={item.color} rx="3" ry="3"></rect>
            <text class="label" x="1285" y={(index * fy_offset * 2) + 55}>{item.label}</text>
        {/each}
    {/if}

    
</svg>

<div class="tooltip" class:visible={tooltip.visible} style="left: {tooltip.x}px; top: {tooltip.y}px;">
    {tooltip.content}
    <canvas id="myChart"></canvas>
</div>

