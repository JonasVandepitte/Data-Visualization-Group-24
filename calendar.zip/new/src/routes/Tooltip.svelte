<!-- Tooltip.svelte -->
<script>
    export let content = ''; // 传入的内容
</script>

<div class="tooltip">
    {content}
</div>

<style>
    .tooltip {
        position: absolute;
        padding: 10px;
        background: white;
        border: 1px solid black;
        z-index: 100;
        pointer-events: none; /* 确保工具提示不会影响鼠标事件 */
        display: none; /* 默认不显示 */
    }
</style>
