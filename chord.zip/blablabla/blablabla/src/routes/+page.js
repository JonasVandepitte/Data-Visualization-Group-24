// import {readFile} from 'fs'
import Papa from 'papaparse'

// const filePath = "http://localhost:5173/dummy.csv";  // Update this to your CSV file path

// export const test = (filePath) => {
//     return Papa.parse(filePath, (e) => {})
// }

// export function load(filePath) {
//     readFile(filePath, 'utf8', (err, data) => {
//         if (err) {
//             console.error('Error reading the file:', err);
//             return;
//         }
//         Papa.parse(data, {
//             complete: function(results) {
//                 console.log(results.data);
//             },
//             error: function(err) {
//                 console.error('Error parsing:', err);
//             }
//         });
//     });
// }

export const load = async ({ fetch }) => {

    const responseFlights = await fetch('http://localhost:5173/dummy2.csv', {
      headers: {
        'Content-Type': 'text/csv'
    }})
    let csvFlights = await responseFlights.text()
    let parsedCsvFlights = Papa.parse(csvFlights, {header: true})

    return {
      orders: parsedCsvFlights.data
    }
}