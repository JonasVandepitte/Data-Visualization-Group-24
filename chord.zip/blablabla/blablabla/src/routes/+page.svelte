<script>
  import { arc, chord, descending, range, ribbon, tickStep } from 'd3';
  // import data from './chord-data' // or pass data to component as prop
  // export let data
  const data = [
    [207330 ,34254 ,192430 ,27358 ,21558 ,72296 ,22069 ,75169],
    [34254 ,5376 ,31665 ,4424 ,3477 ,11744 ,3446 ,12309],
    [192430 ,31665 ,777642 ,25540 ,19789 ,66528 ,20035 ,68959],
    [27358 ,4424 ,25540 ,3580 ,2889 ,9527 ,2912 ,9887 ],
    [21558 ,3477 ,19789 ,2889 ,2182 ,7551 ,2203 ,7693 ],
    [72296 ,11744 ,66528 ,9527 ,7551 ,25012 ,7491 ,25850],
    [22069 ,3446 ,20035 ,2912 ,2203 ,7491 ,2142 ,7811 ],
    [75169 ,12309 ,68959 ,9887 ,7693 ,25850 ,7811 ,26772]
  ];

  const marginOffset = 100 // the margin top, bottom, left, right margin offset relative to the radius
  const width = 800; // the outer width of the chart, in pixels
  const bandThickness = 10; // the thickness of the color band representing each dataset
  const fontSize = 0.8 //the label font size relative to 1% of the width of the viewport
  const tickCount = 100; //the chart label tick spread factor
  const scaleFormat = 'k'; // a format specifier string for the scale ticks
  const names = ['ADVENTURING EQUIPMENT',  'ANIMALS & TRANSPORTATION',  'ARMS & ARMOUR',  'JEWELRY',  'MUSICAL INSTRUMENT',  'POTIONS & SCROLLS',  'SUMMONING DEVICE',  'TOOLS & KITS']; // section names
  const colors = ['#69b40f','#ec1d25','#008fc8','#10218b', '#cbafd6','#FA847E','#0A0554','#FFBF00']; // section fill colors && number of colors in fill array MUST match number of subsets in data
  const chordOpacity = 0.7; //the opacity for the charts overall chords
  const unselectOpacity = 0.1; //the opacity of non-select chart elements
  const selectOpacity = 0.7; //the opacity of select chart elements
  const tooltipBackground = 'lightgrey'; // background color of tooltip
  const tooltipTextColor = 'black'; // text color of tooltip
  const height = width; // the outer height of the chart, in pixels
  const outerRadius = Math.min(width, height) * 0.5 - marginOffset; // should connect to margin
  const innerRadius = outerRadius - bandThickness; // should make adjustable
  
  let groupInfo, ribbonInfo;
  $: reactiveSelectedChord = null;
  $: reactiveTickStep = tickStep(0, data.flat().reduce((a, b) => a + b, 0), tickCount);
  const d3chord = chord()
    .padAngle(10 / innerRadius)
    .sortSubgroups(descending)
    .sortChords(descending);
  const chords = d3chord(data);
  const d3arc = arc()
    .innerRadius(innerRadius)
    .outerRadius(outerRadius);
  const d3ribbon = ribbon()
    .radius(innerRadius - 1)
    .padAngle(1 / innerRadius);
  const ticks = ({startAngle, endAngle, value}, total) => {
    const k = (endAngle - startAngle) / total;
    return range(0, total, reactiveTickStep).map(value => {
      return {value: value / total, angle: value * k + startAngle};
    });
  }
  const formatValue = (val, total) => {
    const percentage = (val/total)*100;
    return percentage.toFixed(2) + '%';
  }
</script>

  
<svg {width} {height} viewBox="{-width / 2 - 50} {-height / 2 - 50} {width + 150} {height + 100}" >
  {#each chords.groups as group, i}
    <path role='presentation' fill={colors[i]} d={d3arc(group)}
      on:mouseover="{(e) => groupInfo = [i, e, group.value]}"
      on:focus="{(e) => groupInfo = [i, e]}"
      on:mouseout="{() => groupInfo = null}"
      on:blur="{() => groupInfo = null}" />
    {#if (i < names.length) && (i != 1)}
    <text x="{(outerRadius + 60) * Math.sin(group.startAngle + (group.endAngle - group.startAngle) / 2)}" y="{-(outerRadius + 60) * Math.cos(group.startAngle + (group.endAngle - group.startAngle) / 2)}" text-anchor="middle" fill={colors[i]} font-size="12">
      {names[i]}
    </text>
    {/if}
    {#if i === 1}
    <text x="{(outerRadius + 95) * Math.sin(group.startAngle + (group.endAngle - group.startAngle) / 2)}" y="{-(outerRadius + 60) * Math.cos(group.startAngle + (group.endAngle - group.startAngle) / 2)}" text-anchor="middle" fill={colors[i]} font-size="12">
      {names[i]}
    </text>
    {/if}
    {#each ticks(group) as groupTick}
      <g transform="rotate({groupTick.angle * 180 / Math.PI - 90}) translate({outerRadius + 10}, 0)">
        <line stroke='black' x2='6'/>
        <!-- No text here -->
      </g>
    {/each}
  {/each}
  
  {#each chords as chord}
    {#if reactiveSelectedChord}
      <path role='presentation' fill-opacity={reactiveSelectedChord === chord ? selectOpacity : unselectOpacity} fill={colors[chord.source.index]} d={d3ribbon(chord)}
        on:mouseover="{(e) => {ribbonInfo = [e, chord]; reactiveSelectedChord = chord; }}"
        on:focus="{(e) => {ribbonInfo = [e, chord]; reactiveSelectedChord = chord; }}"
        on:mouseout="{() => { ribbonInfo = null; reactiveSelectedChord = null; }}"
        on:blur="{() => { ribbonInfo = null; reactiveSelectedChord = null; }}"
      />
    {:else}
    <path role='presentation' fill-opacity={chordOpacity} fill={colors[chord.source.index]} d={d3ribbon(chord)}
      on:mouseover="{(e) => {ribbonInfo = [e, chord]; reactiveSelectedChord = chord; }}"
      on:focus="{(e) => {ribbonInfo = [e, chord]; reactiveSelectedChord = chord; }}"
      on:mouseout="{() => { ribbonInfo = null; reactiveSelectedChord = null; }}"
      on:blur="{() => { ribbonInfo = null; reactiveSelectedChord = null; }}"
    />
    {/if}
  {/each}
</svg>

<!-- Group Tooltip -->
{#if groupInfo}  
  <div class="tooltip" style="position:absolute; left:{groupInfo[1].clientX + 12}px; top:{groupInfo[1].clientY + 12}px; background-color:{tooltipBackground}; color:{tooltipTextColor}">
    {names[groupInfo[0]]}: {(groupInfo[2] * 100).toFixed(2)}{scaleFormat}
  </div>
{/if}

<!-- Ribbon Tooltip -->
{#if ribbonInfo}  
<div class="tooltip" style="position:absolute; left:{ribbonInfo[0].clientX + 12}px; top:{ribbonInfo[0].clientY + 12}px; background-color:{tooltipBackground}; color:{tooltipTextColor}">
  {formatValue(ribbonInfo[1].source.value, data[ribbonInfo[1].source.index].reduce((acc, cur) => acc + cur, 0))} {names[ribbonInfo[1].target.index]} → {names[ribbonInfo[1].source.index]}
  {ribbonInfo[1].source.index === ribbonInfo[1].target.index 
  ? ''
  : `\n${formatValue(ribbonInfo[1].target.value, data[ribbonInfo[1].target.index].reduce((acc, cur) => acc + cur, 0))} ${names[ribbonInfo[1].source.index]} → ${names[ribbonInfo[1].target.index]}`}
</div>
{/if}
  
<style>
  div {
    white-space: pre;
  }

  .tooltip{
    border-radius: 5px;
    padding: 5px;
    box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
  }
</style>
